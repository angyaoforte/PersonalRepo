// Forte Vision — serverless LLM function (Netlify)
// The Anthropic API key lives ONLY in the ANTHROPIC_API_KEY environment variable,
// set in the Netlify dashboard. It is never sent to the browser.

const API_KEY = process.env.ANTHROPIC_API_KEY;
const ACCESS_CODE = process.env.ACCESS_CODE || ""; // optional shared team code (leave unset to disable)
const MODEL_FAST = process.env.MODEL_FAST || "claude-3-5-haiku-latest";   // live suggestions (frequent, cheap)
const MODEL_SMART = process.env.MODEL_SMART || "claude-3-5-sonnet-latest"; // heavier generation (gaps/prereqs/plan)

// ---- shared context given to the model on every call ----
const CONTEXT = `Forte is a small startup running an AI-upskilling program to move everyone into the top 5% of AI users. The goal is that people REDESIGN how they work — thinking in workflows, delegating heavy and repetitive tasks, and building things that run without them.

Always push people UP this ambition ladder:
- ASSIST (lowest): AI helps inside a chat — draft, summarize, answer a question. Useful, but the floor.
- REDESIGN: a whole workflow runs end to end — raw input goes in, AI does the steps, a finished output comes out. Not one chat, a pipeline.
- DELEGATE (highest): an agent or automation performs the full task on its own and only surfaces exceptions for a human.

Real builds already in this team — use them as concrete, believable inspiration:
- a Cowork flow that clears a meeting-transcript backlog and assigns owners
- an outreach engine that researches each prospect from a CSV and drafts a tailored email
- a grant-eligibility scorer with a saved checklist that drafts the first submission
- a brand skill that makes every deck and one-pager come out on-brand

Rules for your output:
- Be concrete and specific to THIS person's role. Never generic.
- Prefer REDESIGN and DELEGATE examples over ASSIST ones. If the person is only describing chat-assist, nudge them higher.
- Warm, plain, simple language — many readers speak English as a second language.
- Respond in the requested language.`;

const LANG = { en: "Respond in English.", es: "Responde en español." };

function resp(status, obj) {
  return {
    statusCode: status,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
    body: JSON.stringify(obj),
  };
}

async function callClaude(model, system, userText, maxTokens) {
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model,
      max_tokens: maxTokens,
      system,
      messages: [{ role: "user", content: userText }],
    }),
  });
  if (!r.ok) {
    const t = await r.text();
    throw new Error("LLM " + r.status + ": " + t.slice(0, 400));
  }
  const j = await r.json();
  return j && j.content && j.content[0] && j.content[0].text ? j.content[0].text : "";
}

function extractJson(text) {
  let t = String(text || "").trim();
  t = t.replace(/^```(?:json)?/i, "").replace(/```$/,"").trim();
  try { return JSON.parse(t); } catch (e) {}
  // fall back to slicing the outermost braces/brackets
  const first = Math.min(...[t.indexOf("{"), t.indexOf("[")].filter((n) => n >= 0));
  const last = Math.max(t.lastIndexOf("}"), t.lastIndexOf("]"));
  if (isFinite(first) && last > first) {
    try { return JSON.parse(t.slice(first, last + 1)); } catch (e) {}
  }
  throw new Error("Could not parse JSON from model output");
}

const clip = (s, n) => String(s == null ? "" : s).slice(0, n);
function clipRows(rows) {
  if (!Array.isArray(rows)) return [];
  return rows.slice(0, 15).map((r) => ({
    category: clip(r && r.category, 160),
    human: clip(r && r.human, 600),
    ai: clip(r && r.ai, 600),
  }));
}
function rowsToText(rows) {
  if (!rows.length) return "(no rows yet)";
  return rows
    .map((r, i) => `Row ${i + 1} — Part of role: ${r.category || "(unnamed)"}\n  What I do: ${r.human || "-"}\n  What AI does: ${r.ai || "-"}`)
    .join("\n");
}

// ---- per-action prompt builders ----
function buildPrompt(action, body, lang) {
  const langLine = LANG[lang];
  const role = clip(body.role, 1500);
  const rows = clipRows(body.rows);
  const rowsTxt = rowsToText(rows);

  if (action === "extract") {
    return {
      model: MODEL_FAST,
      maxTokens: 500,
      system: `${CONTEXT}\n${langLine}\nYou break a described role into its distinct parts.`,
      user: `Here is how someone describes their role:\n"""${role}"""\n\nList the 4–7 distinct PARTS of this role (categories of work). Also add 1–2 parts they likely have but did not mention.\nReturn ONLY JSON: {"parts":["...","..."]}`,
    };
  }
  if (action === "ideas") {
    return {
      model: MODEL_FAST,
      maxTokens: 550,
      system: `${CONTEXT}\n${langLine}\nYou are a fast live advisor. Keep it short and punchy.`,
      user: `The person is filling in a "what I do vs. what AI does" split for their role.\n\n${rowsTxt}\n\nGive quick, ambitious ideas. Return ONLY JSON:\n{"aiCould":["3-4 specific things AI could take on, favoring REDESIGN/DELEGATE over chat-assist"],"missing":["1-3 parts of their role they haven't added yet, or where they're aiming too low"]}`,
    };
  }
  if (action === "gaps") {
    return {
      model: MODEL_SMART,
      maxTokens: 800,
      system: `${CONTEXT}\n${langLine}\nYou review a role for blind spots.`,
      user: `Role description:\n"""${role}"""\n\nTheir current split:\n${rowsTxt}\n\nDo a thorough review. Return ONLY JSON:\n{"missing":[{"area":"a part of their role they haven't addressed","why":"one sentence why it matters"}],"underAiming":[{"row":"which row/category","suggestion":"the more ambitious REDESIGN or DELEGATE version"}]}`,
    };
  }
  if (action === "prereqs") {
    return {
      model: MODEL_SMART,
      maxTokens: 1000,
      system: `${CONTEXT}\n${langLine}\nYou translate 'what AI does' into concrete prerequisites for people who don't think in processes.`,
      user: `Their split:\n${rowsTxt}\n\nFor each meaningful "what AI does" item, list what has to exist first for it to actually work — a connected tool, a saved skill, data in one place, a written rule, an approval. Be concrete. Return ONLY JSON:\n{"prereqs":[{"aiItem":"the AI-does item","needs":["prerequisite 1","prerequisite 2"]}]}`,
    };
  }
  if (action === "plan") {
    const prereqs = clip(JSON.stringify(body.prereqs || []), 3000);
    return {
      model: MODEL_SMART,
      maxTokens: 1100,
      system: `${CONTEXT}\n${langLine}\nYou turn a vision into things a person can start tomorrow.\n\nTraining catalog to choose from (use the closest fits; you may also propose an internal "build this" project):\n- Intro to Model Context Protocol — Anthropic (free) https://anthropic.skilljar.com\n- Record a Skill (practice, no code) https://claude.ai\n- Intro to Agent Skills — Anthropic (free) https://anthropic.skilljar.com\n- AI Design courses — Domestika (Spanish options) https://www.domestika.org/en/courses/area/251-ai-design\n- Adobe Firefly + Photoshop AI 2026 guide https://www.labasad.com/en/adobe-firefly-and-photoshop-ai-in-2026/\n- Gamma — fast decks https://gamma.app\n- AI for Sales — HubSpot Academy (free) https://academy.hubspot.com/\n- monday.com AI & automations https://monday.com/\n- AI & data fundamentals — DataCamp https://www.datacamp.com/`,
      user: `Role:\n"""${role}"""\n\nSplit:\n${rowsTxt}\n\nPrerequisites they've noted:\n${prereqs}\n\nProduce a plan that turns this into action. Return ONLY JSON:\n{"firstBuilds":[{"title":"a concrete build they could start tomorrow","firstStep":"the very first step"}],"trainings":[{"title":"from the catalog or an internal build","why":"one line, tied to their vision","url":"link or empty string"}],"sequence":["3-5 short ordered steps over the next 6 months"]}`,
    };
  }
  return null;
}

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return resp(200, {});
  if (event.httpMethod !== "POST") return resp(405, { error: "Method not allowed" });
  if (!API_KEY) return resp(500, { error: "Server not configured: ANTHROPIC_API_KEY is missing." });

  let body;
  try { body = JSON.parse(event.body || "{}"); }
  catch (e) { return resp(400, { error: "Invalid request body" }); }

  if (ACCESS_CODE && body.code !== ACCESS_CODE) {
    return resp(401, { error: "Invalid or missing team access code." });
  }

  const lang = body.lang === "es" ? "es" : "en";
  const action = body.action;
  const spec = buildPrompt(action, body, lang);
  if (!spec) return resp(400, { error: "Unknown action: " + action });

  try {
    const text = await callClaude(spec.model, spec.system, spec.user, spec.maxTokens);
    const data = extractJson(text);
    return resp(200, { ok: true, data });
  } catch (e) {
    return resp(502, { error: "The advisor is unavailable right now. Try again in a moment.", detail: String(e.message || e).slice(0, 300) });
  }
};
